package cs3500.threetrios.model.Card;

/**
 * The regular card Interface.
 */
public interface IRegularCard extends ICard {
}
