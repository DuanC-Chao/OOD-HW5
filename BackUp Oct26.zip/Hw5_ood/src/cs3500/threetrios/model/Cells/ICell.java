package cs3500.threetrios.model.Cells;

import cs3500.threetrios.model.Card.ICard;
import cs3500.threetrios.model.Exception.CouldNotPlaceCardException;

/**
 * Represent a Cell on the Grid.
 */
public interface ICell<C extends ICard> {

  /**
   * Get the current card on the cell.
   * @return The card got, if no card exist, or Cell is Hole, return Null.
   */
  public C getCard();

  /**
   * Takes an ICard and set as the Cell's card.
   * @param card The card wished to settle.
   * @throws IllegalArgumentException If Card is null.
   * @throws CouldNotPlaceCardException If Already Exist a card in the Cell or Cell is a Hole.
   */
  public void setCard(C card) throws CouldNotPlaceCardException;

}
