package cs3500.threetrios.model.Cells;

import cs3500.threetrios.model.Card.ICard;
import cs3500.threetrios.model.Card.IRegularCard;
import cs3500.threetrios.model.Card.RegularCard;
import cs3500.threetrios.model.Exception.CouldNotPlaceCardException;

/**
 * The CardCell, which is the cell that could hold a card.
 */
public class RegularCardCell implements ICell<IRegularCard> {

  /**
   * Represent the card this Cell currently holds.
   */
  private IRegularCard card;

  /**
   * The default constructor.
   */
  public RegularCardCell() {

  }

  @Override
  public IRegularCard getCard() {
    return card;
  }

  @Override
  public void setCard(IRegularCard card) throws CouldNotPlaceCardException {
    if(card == null) {
      throw new IllegalArgumentException();
    }
    if(this.card != null) {
      throw new CouldNotPlaceCardException("Already placed card to this Cell");
    }
    this.card = card;
  }


}
