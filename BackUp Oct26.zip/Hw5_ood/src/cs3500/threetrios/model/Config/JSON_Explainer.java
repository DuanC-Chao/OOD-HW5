package cs3500.threetrios.model.Config;

import java.util.List;

import cs3500.threetrios.model.Card.RegularCard;

/**
 * This class explains JSON file, work with CardFactory, dynamically construct board.
 */
public class JSON_Explainer {

  static List<RegularCard> get
}
