package cs3500.threetrios.model.Enums;

/**
 * Represent All possible card numbers.
 */
public enum CardNumber {
  ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, A;
}
