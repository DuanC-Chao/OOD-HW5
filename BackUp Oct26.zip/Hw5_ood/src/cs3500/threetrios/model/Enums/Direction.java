package cs3500.threetrios.model.Enums;

/**
 * An Enum for all possible directions.
 */
public enum Direction {
  EAST, WEST, NORTH, SOUTH;
}
