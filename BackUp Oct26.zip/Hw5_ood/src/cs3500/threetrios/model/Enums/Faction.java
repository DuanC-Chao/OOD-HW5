package cs3500.threetrios.model.Enums;

/**
 * Not Implemented in any way yet (Oct 26).
 * Just added in case there will be rules we need to add related to the card's faction later.
 */
public enum Faction {
  BEAST_TRIBE, PRIMALS, THE_WARRING_TRIAD, BEASTMAN, GARLEAN_EMPIRE, HUMANOID, OTHERS;
}
