package cs3500.threetrios.model.Rule;

/**
 * Represents a general rule.
 */
public interface IGeneralRule extends IRule {
}
