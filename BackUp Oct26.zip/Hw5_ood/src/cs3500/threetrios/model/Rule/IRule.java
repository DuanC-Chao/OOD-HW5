package cs3500.threetrios.model.Rule;

/**
 * The main Interface for rule.
 */
public interface IRule {

  int
}
