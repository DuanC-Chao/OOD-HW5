package cs3500.threetrios.model.Enums;

/**
 * An enum, represents all possible cell type.
 */
public enum CellType {
  CARD_CELL, HOLE;
}
