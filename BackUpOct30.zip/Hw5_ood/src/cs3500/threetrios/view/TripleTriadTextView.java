package cs3500.threetrios.view;

/**
 * The plain text version of the view.
 */
public class TripleTriadTextView implements TripleTriadView {

  @Override
  public void render() {

  }
}
