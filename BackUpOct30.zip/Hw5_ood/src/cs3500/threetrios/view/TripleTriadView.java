package cs3500.threetrios.view;

/**
 * The interface for TripleTriad game View.
 */
public interface TripleTriadView {

  /**
   * Render the model.
   */
  void render();
}
