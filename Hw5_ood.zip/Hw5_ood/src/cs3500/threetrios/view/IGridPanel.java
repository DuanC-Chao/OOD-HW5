package cs3500.threetrios.view;

/**
 * The Interface for a Grid Panel.
 * Grid Panel is the panel that shows the status of gameGrid.
 */
public interface IGridPanel extends Refreshable, Discolorable {

}
