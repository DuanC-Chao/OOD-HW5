package cs3500.threetrios.model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

// Assume SimpleBot and AdvancedBot are implementations of a Bot interface that require a MockModel for the move selection

public class BotStrategyTest {

  private TranscriptMockModel transcriptMockModel;
  private ForcedResponseMockModel forcedResponseMockModel;
  private SimpleBot simpleBot;
  private AdvancedBot advancedBot;

  @Before
  public void setUp() {
    // Initialize bot instances and mock models
    simpleBot = new SimpleBot();
    advancedBot = new AdvancedBot();
    transcriptMockModel = new TranscriptMockModel();
    forcedResponseMockModel = new ForcedResponseMockModel();
  }

  // Test SimpleBot for inspecting all possible locations
  @Test
  public void testSimpleBotStrategyWithTranscriptMock() {
    simpleBot.chooseMove(transcriptMockModel); // Run strategy on mock model
    assertTrue("SimpleBot did not inspect all required coordinates",
            transcriptMockModel.getInspectedCoordinates().containsAll(expectedCoordinates()));
  }

  // Test AdvancedBot to ensure it prioritizes corners first
  @Test
  public void testAdvancedBotStrategyWithCorners() {
    advancedBot.chooseMove(transcriptMockModel);
    List<int[]> inspected = transcriptMockModel.getInspectedCoordinates();
    assertTrue("AdvancedBot did not prioritize corners", containsCorners(inspected));
  }

  // Test SimpleBot by forcing a specific move
  @Test
  public void testSimpleBotForcedMove() {
    forcedResponseMockModel.setForcedMove(new int[]{0, 0});
    int[] move = simpleBot.chooseMove(forcedResponseMockModel);
    assertArrayEquals("SimpleBot did not choose the forced move", new int[]{0, 0}, move);
  }

  // Test AdvancedBot by forcing corner moves to be the only valid options
  @Test
  public void testAdvancedBotForcedMove() {
    forcedResponseMockModel.setForcedMove(new int[]{0, 0}, new int[]{0, 2}, new int[]{2, 0}, new int[]{2, 2});
    int[] move = advancedBot.chooseMove(forcedResponseMockModel);
    assertTrue("AdvancedBot did not choose from forced moves", isCorner(move));
  }

  private boolean containsCorners(List<int[]> coordinates) {
    int[][] corners = {{0, 0}, {0, 2}, {2, 0}, {2, 2}};
    for (int[] corner : corners) {
      boolean found = false;
      for (int[] coord : coordinates) {
        if (coord[0] == corner[0] && coord[1] == corner[1]) {
          found = true;
          break;
        }
      }
      if (!found) return false;
    }
    return true;
  }

  private List<int[]> expectedCoordinates() {
    List<int[]> expected = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        expected.add(new int[]{i, j});
      }
    }
    return expected;
  }

  // MockModel interface simulating parts of the game model for bots
  private interface MockModel {
    boolean isLegalMove(int row, int col);
    List<int[]> getInspectedCoordinates();
  }

  // Mock model to log inspected coordinates
  private class TranscriptMockModel implements MockModel {
    private final List<int[]> inspectedCoords = new ArrayList<>();

    @Override
    public boolean isLegalMove(int row, int col) {
      inspectedCoords.add(new int[]{row, col});
      return true;
    }

    @Override
    public List<int[]> getInspectedCoordinates() {
      return inspectedCoords;
    }
  }

  // Mock model to enforce specific moves as legal
  private class ForcedResponseMockModel implements MockModel {
    private List<int[]> forcedMoves = new ArrayList<>();

    public void setForcedMove(int[]... moves) {
      forcedMoves.clear();
      for (int[] move : moves) {
        forcedMoves.add(move);
      }
    }

    @Override
    public boolean isLegalMove(int row, int col) {
      for (int[] move : forcedMoves) {
        if (move[0] == row && move[1] == col) {
          return true;
        }
      }
      return false;
    }

    @Override
    public List<int[]> getInspectedCoordinates() {
      return forcedMoves;
    }
  }

  private boolean isCorner(int[] move) {
    int[][] corners = {{0, 0}, {0, 2}, {2, 0}, {2, 2}};
    for (int[] corner : corners) {
      if (move[0] == corner[0] && move[1] == corner[1]) {
        return true;
      }
    }
    return false;
  }
}

