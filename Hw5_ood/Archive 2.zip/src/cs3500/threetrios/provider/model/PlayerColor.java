package cs3500.threetrios.provider.model;

/**
 * Possible values for the color of a player.
 */
public enum PlayerColor {
  RED,
  BLUE;

}
