package cs3500.threetrios.model;

/**
 * This enum defined all possbile card belonging, which is either player1 or player2.
 */
public enum EPlayer {
  PLAYER_ONE, PLAYER_TWO, EMPTY;
}
