package cs3500.threetrios.view;

/**
 * Interface for a CardButton that is on the grid.
 */
public interface IOnCellCardButton extends ICardButton {


}
