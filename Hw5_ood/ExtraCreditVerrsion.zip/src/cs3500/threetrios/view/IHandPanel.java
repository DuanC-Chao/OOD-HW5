package cs3500.threetrios.view;

/**
 * The Interface for hand panel, hand panel is the conponent that holds all cards.
 * There could be two hand panel in the scene, representing each player's hand.
 */
public interface IHandPanel extends Refreshable {

}
