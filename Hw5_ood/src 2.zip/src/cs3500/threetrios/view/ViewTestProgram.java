package cs3500.threetrios.view;

import java.io.InputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Scanner;

import cs3500.threetrios.model.DefaultCombatRule;
import cs3500.threetrios.model.ITripleTriadModel;
import cs3500.threetrios.model.PredefinedBot;
import cs3500.threetrios.model.TripleTriadModel;

/**
 * The main for graphic view, just for test.
 */
public class ViewTestProgram {

  /**
   * The main class.
   *
   * @param args The args.
   */
  public static void main(String[] args) {

    String boardConfigPath = loadResourceFile("/SimpleBoard.txt");
    String cardConfigPath = loadResourceFile("/SevenCardsDeck.txt");

    //String boardConfigPath_Big = "src/../resources/MediumSizeBoard.txt";
    //String cardConfigPath = "src/../resources/SimpleDeck.txt";

    ITripleTriadModel model = new TripleTriadModel();
    model.startGame(boardConfigPath, cardConfigPath, "A", "B",
      false, new DefaultCombatRule(), PredefinedBot.ADVANCED_BOT.getBot());
    TripleTriadGraphcView view = new TripleTriadGraphcView(model);

    //model.playToGrid(1, 0, 0, 0);

    //model.playToGrid(1, 0, 0, 1);

    refresh(view);
  }

  private static void refresh(TripleTriadGraphcView view) {
    try {
      view.render(null);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Helper method, load file with just name, and create temp file.
   * And return absolute path of that temp file.
   *
   * @param resourcePath Config file's name on JAR.
   * @return Absolute path of temp file.
   */
  private static String loadResourceFile(String resourcePath) {
    try (InputStream inputStream = ViewTestProgram.class.getResourceAsStream(resourcePath)) {
      if (inputStream == null) {
        throw new IllegalArgumentException("Resource not found: " + resourcePath);
      }

      File tempFile = File.createTempFile("temp_", ".txt");
      tempFile.deleteOnExit();

      try (FileOutputStream outStream = new FileOutputStream(tempFile);
           Scanner scanner = new Scanner(inputStream)) {
        while (scanner.hasNextLine()) {
          String line = scanner.nextLine();
          outStream.write((line + "\n").getBytes());
        }
      }
      return tempFile.getAbsolutePath();

    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

}
