package cs3500.threetrios.provider.model;

/**
 * Represents whether a hole is occupiable or not.
 */
public enum CellType {
  HOLE,
  OCCUPIABLE
}
