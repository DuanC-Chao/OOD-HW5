package cs3500.threetrios.model;

/**
 * An Enum for all possible directions.
 */
public enum Direction {
  EAST, WEST, NORTH, SOUTH;
}
